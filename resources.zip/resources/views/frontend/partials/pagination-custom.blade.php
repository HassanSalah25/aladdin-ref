<style>
    .pagination .page-item.active .page-link {
        color: var(--primary);
    }
</style>
