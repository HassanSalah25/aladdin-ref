<?php

return array (
  'admin-account' => 'Admin',
  'copy-to-login' => 'Copy',
  'demo-login-credentials' => 'Please use our demo account for login',
  'user-account' => 'User',
);
