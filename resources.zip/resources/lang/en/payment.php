<?php

return array (
  'enable-paypal' => 'Enable PayPal',
  'enable-razorpay' => 'Enable Razoray',
  'pay-paypal' => 'Pay with PayPal',
  'pay-razorpay' => 'Pay with Razorpay',
  'payment' => 'Payment',
  'paypal' => 'PayPal',
  'paypal-disable' => 'PayPal payment gateway disabled.',
  'paypal-ipn' => 'PayPal IPN',
  'razorpay' => 'Razorpay',
);
