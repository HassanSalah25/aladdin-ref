<?php

return array (
  'category-description' => 'Category Description',
  'records' => 'records in total',
);
