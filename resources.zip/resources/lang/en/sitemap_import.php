<?php

return array (
  'alert' => 
  array (
    'url-starts-with' => 'URL must starts with http:// or https://',
  ),
  'column-item-feature-image' => 'listing feature image URL',
  'column-item-gallery-images' => 'listing gallery images URLs',
  'csv-file-upload-listing-instruction-columns' => 'Columns for listing: title, slug (option), address (option), city, state, country, latitude (option), longitude (option), postal code, description (option), phone (option), website (option), facebook (option), twitter (option), linkedin (option), instagram (option), whatsapp (option), youtube id (option), featured image URL (option), gallery images URLs (option), timezone (option), show hours (option), hours (option), exceptional hours (option).',
  'csv-file-upload-listing-instruction-gallery-images-urls' => 'In the gallery images URLs column, please separate each image URL with whitespace.',
  'csv-file-upload-listing-instruction-image-urls' => 'URLs must starts with http:// or https:// in both featured image URL and gallery images URLs columns.',
  'item-feature-image-url-help' => 'Enter image url starts with http:// or https://',
  'item-gallery-images-url-help' => 'Enter image URLs starts with http:// or https:// and one line per URL',
  'sitemap' => 
  array (
    'city' => 'City',
    'state' => 'State',
  ),
);
