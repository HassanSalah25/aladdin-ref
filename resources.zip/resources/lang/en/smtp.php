<?php

return array (
  'from-email' => 'From email',
  'from-name' => 'From name',
  'smtp' => 'SMTP',
  'smtp-enabled' => 'Enable SMTP',
  'smtp-encryption' => 'SMTP encryption',
  'smtp-encryption-null' => 'NULL',
  'smtp-encryption-ssl' => 'SSL',
  'smtp-encryption-tls' => 'TLS',
  'smtp-host' => 'SMTP host',
  'smtp-password' => 'SMTP password',
  'smtp-port' => 'SMTP port',
  'smtp-username' => 'SMTP username',
);
