<?php

return array (
  'blogger' => 'Blogger',
  'buffer' => 'Buffer',
  'evernote' => 'Evernote',
  'facebook' => 'Facebook',
  'line' => 'Line',
  'linkedin' => 'LinkedIn',
  'pinterest' => 'Pinterest',
  'reddit' => 'Reddit',
  'skype' => 'Skype',
  'telegram' => 'Telegram',
  'twitter' => 'Twitter',
  'viber' => 'Viber',
  'wechat' => 'Wechat',
  'weibo' => 'Weibo',
  'whatsapp' => 'Whatsapp',
  'wordpress' => 'Wordpress',
);
