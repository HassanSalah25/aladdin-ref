<?php

return array (
  'category-name-a-z' => 'Name A-Z',
  'category-name-z-a' => 'Name Z-A',
  'custom-field-name-a-z' => 'Name A-Z',
  'custom-field-name-z-a' => 'Name Z-A',
  'test-smtp' => 
  array (
    'email-body' => 'This is a test email in order to verify the functionality of the SMTP. The following is a randomly generated paragraph text.',
    'email-subject' => 'Please verify this test of sending email via SMTP',
    'enable-smtp-notify' => 'Please enable SMTP in order to proceed with a test.',
    'error-notify' => 'An error occurred for sending out the test email:',
    'modal' => 
    array (
      'modal-description' => 'A testing email will be sent to the email address you entered below with the SMTP setting you provided.',
      'modal-send' => 'Send now',
      'modal-title' => 'Test SMTP Setting',
    ),
    'receiver-email' => 'Receiver email',
    'send-a-test-email-link' => 'Send a test email',
    'success-notify' => 'The test email has been sending out successfully. Please check your email inbox or spam box for verification. For your information, the test email has been sent to:',
  ),
);
