<?php

return array (
  'alert' => 
  array (
    'update-razorpay-success' => 'Razorpay setting updated successfully.',
    'value-required' => 'required',
  ),
  'edit-razorpay-setting' => 'Edit Razorpay payment gateway',
  'edit-razorpay-setting-desc' => 'This page allows you enable or disable Razorpay payment gateway, and edit Razorpay settings.',
  'enable-razorpay' => 'Enable Razorpay payment gateway',
  'razorpay-disabled' => 'Razorpay Disabled',
  'razorpay-enabled' => 'Razorpay Enabled',
  'seo' => 
  array (
    'edit-razorpay' => 'Dashboard - Edit Razorpay - :site_name',
  ),
);
