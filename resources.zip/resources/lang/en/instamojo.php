<?php

return array (
  'alert' => 
  array (
    'instamojo-failed' => 'Instamojo Payment failed.',
    'instamojo-success' => 'Instamojo Payment success.',
    'instamojo-wrong' => 'Something went wrong with Instamojo',
  ),
);
