<?php

return array (
  'alert' => 
  array (
    'update-paypal-success' => 'PayPal setting updated successfully.',
    'value-required' => 'required',
  ),
  'edit-paypal-setting' => 'Edit PayPal payment gateway',
  'edit-paypal-setting-desc' => 'This page allows you enable or disable PayPal payment gateway, and edit PayPal settings.',
  'enable-paypal' => 'Enable PayPal payment gateway',
  'paypal-disabled' => 'PayPal Disabled',
  'paypal-enabled' => 'PayPal Enabled',
  'paypal-live' => 'Live',
  'paypal-sandbox' => 'Sandbox',
  'seo' => 
  array (
    'edit-paypal' => 'Dashboard - Edit PayPal - :site_name',
  ),
);
