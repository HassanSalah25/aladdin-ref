<?php

return array (
  'delete-custom-field-warning' => 'Deleting the custom field will also delete the listing features data associated with this custom field.',
);
