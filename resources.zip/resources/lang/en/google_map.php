<?php

return array (
  'get-directions' => 'Get Directions',
  'google-map' => 'Google Map',
  'google-map-api-key' => 'Google API Key',
  'map' => 'Map',
  'open-street-map' => 'OpenStreetMap',
  'select-lat-lng-on-map' => 'Click on map to get Lat and Lng',
  'select-map' => 'Choose Map',
  'select-map-help' => 'Choose which map to use in the website',
);
