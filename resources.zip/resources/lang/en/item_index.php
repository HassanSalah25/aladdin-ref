<?php

return array (
  'alert' => 
  array (
    'bulk-approved' => 'Selected listings have been approved successfully.',
    'bulk-deleted' => 'Selected listings have been deleted successfully.',
    'bulk-disapproved' => 'Selected listings have been disapproved successfully.',
    'bulk-suspended' => 'Selected listings have been suspended successfully.',
  ),
  'approve-selected' => 'Approve Listings',
  'delete-selected' => 'Delete Listings',
  'delete-selected-items-confirm' => 'Do you want to delete selected listings?',
  'disapprove-selected' => 'Disapprove Listings',
  'suspend-selected' => 'Suspend Listings',
);
