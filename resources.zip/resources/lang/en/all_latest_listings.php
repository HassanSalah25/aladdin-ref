<?php

return array (
  'view-all-latest' => 'View All Listings',
);
