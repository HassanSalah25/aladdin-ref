<?php

return array (
  'choose-photo' => 'Choose Photos',
  'upload-photos' => 'Upload your photos',
  'upload-photos-help' => 'You can upload up to 12 photos',
);
