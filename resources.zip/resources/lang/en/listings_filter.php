<?php

return array (
  'categories' => 'Categories',
  'filters' => 'Filters',
  'products-per-page' => 'Products Count',
  'show-less' => 'Show less',
  'show-more' => 'Show more',
  'sort-by' => 'Sort by',
  'sort-by-highest' => 'Highest Rated',
  'sort-by-lowest' => 'Lowest Rated',
  'sort-by-newest' => 'Newest First',
  'sort-by-oldest' => 'Oldest First',
  'sort-by-price-high' => 'Highest Price',
  'sort-by-price-low' => 'Lowest Price',
  'update-result' => 'Update',
);
