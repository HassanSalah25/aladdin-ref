<?php

return array (
  'purchase-button' => 'Purchase',
  'purchase-desc' => 'We don\'t sell this product outside of CodeCanyon. Purchase from this original author for support and lifetime updates.',
);
