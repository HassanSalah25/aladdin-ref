<?php

return array (
  'column-item-social-instagram' => 'listing instagram',
  'column-item-social-whatsapp' => 'listing whatsapp',
  'import-error' => 
  array (
    'whatsapp-error' => 'Please make sure whatsapp number only include country code + number, omit any zeroes, brackets, dashes, or empty space. e.g. 17086546789',
  ),
  'item-social-instagram' => 'Instagram',
  'item-social-instagram-help' => 'Instagram username',
  'item-social-whatsapp' => 'Whatsapp',
  'item-social-whatsapp-help' => 'whatsapp number, include country code + number, omit any zeroes, brackets, dashes, or empty space. e.g. 17086546789',
);
