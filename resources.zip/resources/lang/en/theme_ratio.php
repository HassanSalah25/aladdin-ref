<?php

return array (
  'image-background-help' => 'Recommend minimum ratio:',
);
