<?php

return array (
  'alert' => 
  array (
    'invalid-transaction' => 'معاملة غير صالحة ، يرجى المحاولة مرة أخرى.',
    'payment-canceled' => 'تم إلغاء دفع Payumoney',
    'payment-paid' => 'دفع Payumoney بنجاح',
    'payumoney-disable' => 'بوابة الدفع Payumoney معطلة.',
    'updated-success' => 'تم تحديث إعداد Payumoney بنجاح',
    'value-required' => 'مطلوب',
  ),
  'edit-payumoney-setting' => 'تحرير بوابة الدفع Payumoney',
  'edit-payumoney-setting-desc' => 'تتيح لك هذه الصفحة تمكين أو تعطيل بوابة دفع Payumoney ، وتعديل إعدادات Payumoney.',
  'enable-payumoney' => 'تفعيل بوابة الدفع Payumoney',
  'live' => 'وضع الحية',
  'merchant-key' => 'مفتاح التاجر',
  'merchant-salt' => 'ملح التاجر',
  'mode' => 'الوضع',
  'pay-payumoney' => 'ادفع مع Payumoney',
  'pay-redirect-message' => 'الرجاء الانتظار .. إعادة التوجيه إلى صفحة الدفع Payumoney.',
  'payumoney' => 'بايوموني',
  'payumoney-disabled' => 'Payumoney معطل',
  'payumoney-enabled' => 'تمكين Payumoney',
  'seo' => 
  array (
    'edit-payumoney' => 'لوحة القيادة - تحرير إعداد Payumoney - :site_name',
  ),
  'test' => 'وضع الاختبار',
);
