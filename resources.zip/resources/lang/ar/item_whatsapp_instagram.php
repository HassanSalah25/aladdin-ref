<?php

return array (
  'column-item-social-instagram' => 'سرد الانستغرام',
  'column-item-social-whatsapp' => 'سرد whatsapp',
  'import-error' => 
  array (
    'whatsapp-error' => 'يرجى التأكد من أن رقم whatsapp لا يتضمن سوى رمز البلد + الرقم ، أو حذف أي أصفار ، أو أقواس ، أو شرطات ، أو مساحة فارغة. على سبيل المثال 17086546789',
  ),
  'item-social-instagram' => 'انستغرام',
  'item-social-instagram-help' => 'اسم مستخدم Instagram',
  'item-social-whatsapp' => 'ال WhatsApp',
  'item-social-whatsapp-help' => 'رقم whatsapp ، قم بتضمين رمز البلد + الرقم ، وحذف أي أصفار ، أو أقواس ، أو شرطات ، أو مساحة فارغة. على سبيل المثال 17086546789',
);
