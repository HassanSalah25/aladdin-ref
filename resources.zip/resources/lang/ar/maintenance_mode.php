<?php

return array (
  'admin-login-link' => 'دخول المشرف',
  'admin-login-modal-title' => 'تسجيل الدخول كمسؤول',
  'alert' => 
  array (
    'maintenance-updated' => 'تم تحديث وضع الصيانة بنجاح.',
  ),
  'description' => 'عذرا ، موقعنا قيد الصيانة ، لكن سنعود قريبا!',
  'maintenance-mode-off' => 'وضع الحية',
  'maintenance-mode-off-help' => 'الجمهور لديه حق الوصول إلى موقع الويب الخاص بك.',
  'maintenance-mode-on' => 'نمط الصيانة',
  'maintenance-mode-on-help' => 'لا يستطيع الجمهور الوصول إلى موقع الويب الخاص بك باستثناء مسؤول الموقع.',
  'maintenance-mode-warning' => 'لقد قمت بتسجيل الدخول كمسؤول ، ولديك إمكانية الوصول إلى صفحات الواجهة الأمامية والخلفية لموقع الويب.',
  'maintenance-mode-warning-title' => 'الموقع في وضع الصيانة!',
  'maintenance-setting' => 'اعمال صيانة',
  'maintenance-setting-desc' => 'تتيح لك هذه الصفحة تشغيل موقع الويب أو إيقاف تشغيله في وضع الصيانة.',
  'seo' => 
  array (
    'setting-maintenance' => 'لوحة القيادة - الصيانة - :site_name',
    'title' => 'الموقع في الصيانة',
  ),
  'sidebar' => 
  array (
    'maintenance' => 'اعمال صيانة',
  ),
  'title' => 'سنعود قريبا!',
);
