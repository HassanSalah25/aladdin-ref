<?php

return array (
  'blogger' => 'المدون',
  'buffer' => 'متعادل',
  'evernote' => 'إيفرنوت',
  'facebook' => 'موقع التواصل الاجتماعي الفيسبوك',
  'line' => 'خط',
  'linkedin' => 'ينكدين',
  'pinterest' => 'بينتيريست',
  'reddit' => 'رديت',
  'skype' => 'سكايب',
  'telegram' => 'برقية',
  'twitter' => 'تويتر',
  'viber' => 'فايبر',
  'wechat' => 'ويتشات',
  'weibo' => 'ويبو',
  'whatsapp' => 'ال WhatsApp',
  'wordpress' => 'وورد',
);
