<?php

return array (
  'alert' => 
  array (
    'update-razorpay-success' => 'تم تحديث إعداد Razorpay بنجاح.',
    'value-required' => 'مطلوب',
  ),
  'edit-razorpay-setting' => 'تحرير بوابة الدفع Razorpay',
  'edit-razorpay-setting-desc' => 'تتيح لك هذه الصفحة تمكين بوابة دفع Razorpay أو تعطيلها ، وتعديل إعدادات Razorpay.',
  'enable-razorpay' => 'تفعيل بوابة دفع Razorpay',
  'razorpay-disabled' => 'Razorpay معاق',
  'razorpay-enabled' => 'تمكين Razorpay',
  'seo' => 
  array (
    'edit-razorpay' => 'لوحة القيادة - تحرير Razorpay - :site_name',
  ),
);
