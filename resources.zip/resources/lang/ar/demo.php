<?php

return array (
  'purchase-button' => '',
  'purchase-desc' => '',
);
