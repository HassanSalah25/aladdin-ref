<?php

return array (
  'next' => 'التالى &quot;',
  'previous' => '&quot; السابق',
);
