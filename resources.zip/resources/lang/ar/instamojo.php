<?php

return array (
  'alert' => 
  array (
    'instamojo-failed' => '',
    'instamojo-success' => '',
    'instamojo-wrong' => '',
  ),
);
