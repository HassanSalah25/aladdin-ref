<?php

return array (
  'all-cat' => 'كل التصنيفات',
  'and' => 'و',
  'categories' => 'التصنيفات',
  'category' => 'التصنيف',
  'category-delete-error-children' => 'تحتوي هذه الفئة على فئات فرعية ، يرجى حذف جميع الفئات الفرعية أولاً.',
  'category-name-taken-error' => 'تم أخذ اسم الفئة.',
  'category-slug-help' => 'فقط أحرف ألفا و / أو أحرف صغيرة ، وشرطات وشرطات سفلية.',
  'category-slug-taken-error' => 'تم أخذ سبيكة الفئة.',
  'choose-parent-cat' => 'اختر فئة رئيسية',
  'create-cat-not-found' => 'لم يتم العثور على الفئة الرئيسية.',
  'item-category-update-alert' => 'تم تحديث فئة هذه القائمة بنجاح.',
  'more' => 'أكثر',
  'no-parent-cat' => 'بدون فئة أصل (فئة الجذر)',
  'parent-cat' => 'القسم الرئيسي',
  'search-city-format-alert' => 'يجب أن يكون في المدينة ، تنسيق الولاية',
  'search-city-placeholder' => 'بالقرب من المدينة',
  'search-query-placeholder' => 'مثال: بيتزا ، فندق ، كافية ، محافظة ...',
  'self-parent-cat-error' => 'لا يمكن تعيين الذات كفئة رئيسية.',
  'update-cat' => 'تحديث الفئة',
);
