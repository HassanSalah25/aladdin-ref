<?php

return array (
  'contact' => 
  array (
    'body' => 
    array (
      'body-1' => 'لقد تلقيت رسالة اتصال جديدة من :first_name :last_name',
      'body-2' => 'الموضوع: :subject',
      'body-3' => ':first_name :last_name <:email>',
      'body-4' => 'رسالة:',
    ),
    'subject' => 'رسالة نموذج اتصال جديدة',
  ),
);
