<?php

return array (
  'alert' => 
  array (
    'url-starts-with' => 'يجب أن يبدأ عنوان URL بـ http: // أو https: //',
  ),
  'column-item-feature-image' => 'سرد URL صورة الميزة',
  'column-item-gallery-images' => 'سرد عناوين URL لصور المعرض',
  'csv-file-upload-listing-instruction-columns' => 'أعمدة القائمة: العنوان ، سبيكة (خيار) ، العنوان (خيار) ، المدينة ، الولاية ، البلد ، خط العرض (خيار) ، خط الطول (خيار) ، الرمز البريدي ، الوصف (خيار) ، الهاتف (خيار) ، موقع الويب (خيار) ، facebook (خيار) ، twitter (خيار) ، ينكدين (خيار) ، instagram (خيار) ، whatsapp (خيار) ، معرف youtube (خيار) ، عنوان URL للصورة المميزة (خيار) ، عناوين URL لصور المعرض (خيار) ، المنطقة الزمنية (خيار) ، عرض ساعات (خيار) ، ساعات (خيار) ، ساعات استثنائية (خيار).',
  'csv-file-upload-listing-instruction-gallery-images-urls' => 'في عمود عناوين URL للصور في المعرض ، يرجى فصل كل عنوان URL للصورة بمسافة بيضاء.',
  'csv-file-upload-listing-instruction-image-urls' => 'يجب أن تبدأ عناوين URL بـ http: // أو https: // في أعمدة عناوين URL الخاصة بالصورة المميزة والمعرض.',
  'item-feature-image-url-help' => 'أدخل عنوان url للصورة يبدأ بـ http: // أو https: //',
  'item-gallery-images-url-help' => 'أدخل عناوين URL للصور تبدأ بـ http: // أو https: // وسطر واحد لكل عنوان URL',
  'sitemap' => 
  array (
    'city' => 'مدينة',
    'state' => 'حالة',
  ),
);
