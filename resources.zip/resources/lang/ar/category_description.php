<?php

return array (
  'category-description' => 'وصف التصنيف',
  'records' => 'السجلات في المجموع',
);
