<?php

return array (
  'alert' => 
  array (
    'update-paypal-success' => 'تم تحديث إعداد PayPal بنجاح.',
    'value-required' => 'مطلوب',
  ),
  'edit-paypal-setting' => 'تحرير بوابة الدفع PayPal',
  'edit-paypal-setting-desc' => 'تتيح لك هذه الصفحة تمكين أو تعطيل بوابة دفع PayPal ، وتحرير إعدادات PayPal.',
  'enable-paypal' => 'تمكين بوابة الدفع PayPal',
  'paypal-disabled' => 'تم تعطيل PayPal',
  'paypal-enabled' => 'تمكين PayPal',
  'paypal-live' => 'حي',
  'paypal-sandbox' => 'صندوق الرمل',
  'seo' => 
  array (
    'edit-paypal' => 'لوحة القيادة - تحرير PayPal - :site_name',
  ),
);
