<?php

return array (
  '1-stars' => '1 نجوم',
  '2-stars' => '2 نجوم',
  '3-stars' => '3 نجوم',
  '4-stars' => '4 نجوم',
  '5-stars' => '5 نجوم',
  'based-on-review' => 'بناء على مراجعة :item_rating_count',
  'based-on-reviews' => 'على أساس :item_rating_count التقيمات',
  'contact' => 'اتصل',
  'managed-by' => 'مدير',
  'sort-by' => 'صنف حسب',
  'sort-by-highest' => 'الأعلى تقييما',
  'sort-by-lowest' => 'الأقل تقييما',
  'sort-by-newest' => 'الأحدث أولاً',
  'sort-by-oldest' => 'الأقدم أولا',
);
