<?php

return array (
  'choose-photo' => 'اختر الصور',
  'upload-photos' => 'قم بتحميل صورك',
  'upload-photos-help' => 'يمكنك تحميل ما يصل إلى 12 صورة',
);
