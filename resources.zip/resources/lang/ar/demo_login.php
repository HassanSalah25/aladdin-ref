<?php

return array (
  'admin-account' => 'مشرف',
  'copy-to-login' => 'نسخ',
  'demo-login-credentials' => 'الرجاء استخدام حسابنا التجريبي لتسجيل الدخول',
  'user-account' => 'الاعضاء',
);
