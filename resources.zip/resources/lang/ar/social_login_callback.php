<?php

return array (
  'oauth-redirect-uri' => 'OAuth Redirect URI',
);
