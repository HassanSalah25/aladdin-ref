<?php

return array (
  'alert' => 
  array (
    'edit-success' => 'تم تحديث إعداد Recaptcha بنجاح',
    'site-key-required' => 'مطلوب مفتاح الموقع في حالة تمكين نموذج واحد أو أكثر',
    'site-secret-required' => 'مطلوب سر الموقع في حالة تمكين نموذج واحد أو أكثر',
  ),
  'enable-contact' => 'قم بتمكين Google reCaptcha في نموذج الاتصال',
  'enable-login' => 'قم بتمكين Google reCaptcha في نموذج تسجيل الدخول',
  'enable-sign-up' => 'قم بتمكين Google reCaptcha في نموذج الاشتراك',
  'google-recaptcha' => 'Google reCaptcha الإصدار 2',
  'google-recaptcha-desc' => 'تتيح لك هذه الصفحة تكوين الإصدار 2 من Google reCaptcha على نماذج مواقع الويب.',
  'recaptcha' => 'reCAPTCHA',
  'recaptcha-site-key' => 'مفتاح موقع Google reCaptcha',
  'recaptcha-site-secret' => 'موقع جوجل reCaptcha السري',
  'seo' => 
  array (
    'edit' => 'لوحة القيادة - تحرير Recaptcha - :site_name',
  ),
);
