<?php

return array (
  'categories' => 'التصنيفات',
  'filters' => 'المرشحات',
  'products-per-page' => 'عدد المنتجات في الصفحة',
  'show-less' => 'عرض أقل',
  'show-more' => 'أظهر المزيد',
  'sort-by' => 'صنف حسب',
  'sort-by-highest' => 'الأعلى تقييما',
  'sort-by-lowest' => 'الأقل تقييما',
  'sort-by-newest' => 'الأحدث أولاً',
  'sort-by-oldest' => 'الأقدم أولا',
  'sort-by-price-high' => 'الأعلى سعرا',
  'sort-by-price-low' => 'الأقل سعرا',
  'update-result' => 'تحديث',
);
