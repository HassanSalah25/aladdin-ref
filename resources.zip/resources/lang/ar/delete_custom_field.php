<?php

return array (
  'delete-custom-field-warning' => 'سيؤدي حذف الحقل المخصص إلى حذف بيانات المعالم المرتبطة بهذا الحقل المخصص.',
);
