<?php

return array (
  'get-directions' => 'احصل على الاتجاهات',
  'google-map' => 'خرائط جوجل',
  'google-map-api-key' => 'مفتاح Google API',
  'map' => 'خريطة',
  'open-street-map' => 'OpenStreetMap',
  'select-lat-lng-on-map' => 'انقر على الخريطة للحصول على Lat و Lng',
  'select-map' => 'اختر الخريطة',
  'select-map-help' => 'اختر الخريطة التي تريد استخدامها في الموقع',
);
