<?php

return array (
  'enable-paypal' => 'تمكين PayPal',
  'enable-razorpay' => 'تمكين Razoray',
  'pay-paypal' => 'الدفع بواسط باى بال',
  'pay-razorpay' => 'ادفع مع Razorpay',
  'payment' => 'دفع',
  'paypal' => 'باي بال',
  'paypal-disable' => 'بوابة دفع PayPal معطلة.',
  'paypal-ipn' => 'PayPal IPN',
  'razorpay' => 'رازورباي',
);
