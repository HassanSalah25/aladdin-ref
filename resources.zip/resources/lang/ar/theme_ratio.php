<?php

return array (
  'image-background-help' => 'يوصي النسبة الدنيا:',
);
