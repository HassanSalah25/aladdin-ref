<?php

return array (
  'alert' => 
  array (
    'invalid-signature' => 'تم إرجاع توقيع razorpay غير صالح',
    'invoice-not-found' => 'رقم الفاتورة غير موجود.',
    'payment-canceled' => 'تم إلغاء الدفع بنجاح.',
    'razorpay-disable' => 'بوابة الدفع Razorpay معطلة.',
  ),
  'api-key' => 'معرف مفتاح API',
  'api-secret' => 'سر مفتاح API',
  'cancel-payment' => 'الغاء الدفع',
  'currency' => 'عملة',
  'currency-help' => 'يرجى أولاً تمكين الدفع الدولي في Razorpay إذا كنت تقبل عملات أخرى غير الروبية الهندية (INR)',
  'pay-redirect-message' => 'الرجاء الانتظار ... جارٍ فتح صفحة دفع razorpay.',
  'webhook' => 'الويب هوك',
);
