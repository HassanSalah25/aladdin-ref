<?php

return array (
  'country' => 
  array (
    'alert' => 
    array (
      'disable-default-country' => 'لا يمكن تعطيل هذا البلد لأنه تم تعيينه كبلد افتراضي لموقع الويب.',
    ),
    'country-status' => 'حالة',
    'country-status-disable' => 'إبطال',
    'country-status-enable' => 'ممكن',
    'country-status-help' => 'تعطيله سيمنع المستخدمين من تعيين تفضيل البلد لهذا البلد أو إنشاء قوائم بناءً على هذا البلد.',
  ),
  'language' => 
  array (
    'alert' => 
    array (
      'default-not-in-available-languages' => 'اللغة الافتراضية التي حددتها ليست في قائمة اللغات المتاحة التي قمت بتعيينها',
      'updated-success' => 'تم تحديث إعداد اللغة بنجاح.',
    ),
    'available-website-languages' => 'اللغات المتوفرة',
    'available-website-languages-help' => 'يمكنك تمكين أو تعطيل اللغات المتاحة للموقع.',
    'language-setting' => 'إعدادات اللغة',
    'language-setting-desc' => 'تتيح لك هذه الصفحة تعيين اللغة الافتراضية لموقع الويب ، بالإضافة إلى تمكين أو تعطيل اللغات المتاحة لموقع الويب.',
    'seo' => 
    array (
      'edit' => 'لوحة القيادة - إعداد اللغة - :site_name',
    ),
    'sidebar' => 
    array (
      'language' => 'لغة',
    ),
  ),
  'location' => 
  array (
    'url-slug' => 'رابط URL',
    'url-slug-exist' => 'تم أخذ slug url',
    'url-slug-help' => 'يسمح فقط بأحرف ألفا و / أو رقمية ، وشرطات ، وشرطات سفلية.',
  ),
);
