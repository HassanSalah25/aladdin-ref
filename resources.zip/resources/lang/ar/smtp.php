<?php

return array (
  'from-email' => 'من البريد الإلكترونى',
  'from-name' => 'من الاسم',
  'smtp' => 'SMTP',
  'smtp-enabled' => 'تمكين SMTP',
  'smtp-encryption' => 'تشفير SMTP',
  'smtp-encryption-null' => 'لا شيء',
  'smtp-encryption-ssl' => 'SSL',
  'smtp-encryption-tls' => 'TLS',
  'smtp-host' => 'مضيف SMTP',
  'smtp-password' => 'كلمة مرور SMTP',
  'smtp-port' => 'منفذ SMTP',
  'smtp-username' => 'اسم مستخدم SMTP',
);
