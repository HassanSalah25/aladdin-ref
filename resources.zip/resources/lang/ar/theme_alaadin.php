<?php

return array (
  'filter-button-filter-results' => 'تصفية النتائج',
  'filter-filter-by' => 'تصنيف ',
  'filter-link-reset-all' => 'إستعادة',
  'filter-results' => 'النتائج',
  'filter-sort-by' => 'ترتيب حسب',
  'filter-sort-by-nearby-first' => 'الأماكن الأقرب',
);
